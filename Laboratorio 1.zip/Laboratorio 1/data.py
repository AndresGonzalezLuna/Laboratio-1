# -*- coding: utf-8 -*-
"""
Created on Thu Feb  9 02:07:44 2023

@author: 18and
"""

import pandas as pd
import functions

#%% Leemos el archivo inicial

    #%% Funcion para leer el archivo inicial
    
data = functions.initial_file_reader('files/NAFTRAC_20210129.csv')